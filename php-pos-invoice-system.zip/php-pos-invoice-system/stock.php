<?php include 'config.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><i class="fa-solid fa-boxes-stacked"></i> Stock Management</h2>
    <button class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Stock</button>
</div>

<!-- Stock Filter Tabs -->
<div class="btn-group mb-3" role="group">
    <button type="button" class="btn btn-primary">All Stock</button>
    <button type="button" class="btn btn-outline-secondary">Stock In</button>
    <button type="button" class="btn btn-outline-secondary">Stock Out</button>
    <button type="button" class="btn btn-outline-secondary">Low Stock</button>
</div>

<div class="card p-3 shadow-sm">
    <table class="table table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Product</th>
                <th>Category</th>
                <th>Current Stock</th>
                <th>Min Stock</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $pdo->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id");
            while($s = $stmt->fetch()):
            ?>
            <tr>
                <td><?= $s['id'] ?></td>
                <td><strong><?= $s['name'] ?></strong></td>
                <td><?= $s['category_name'] ?></td>
                <td><?= $s['stock'] ?></td>
                <td><?= $s['min_stock'] ?></td>
                <td>
                    <span class="badge bg-<?= $s['status'] == 'In Stock' ? 'success' : 'warning' ?>">
                        <?= $s['status'] ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-between align-items-center mt-2">
        <small class="text-muted">Showing 1 to 8 of 8 entries</small>
        <nav>
            <ul class="pagination pagination-sm m-0">
                <li class="page-item disabled"><a class="page-link" href="#">&lt;</a></li>
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">&gt;</a></li>
            </ul>
        </nav>
    </div>
</div>

</div>
</body>
</html>